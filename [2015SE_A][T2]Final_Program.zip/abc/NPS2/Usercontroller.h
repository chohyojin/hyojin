#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"


void Usercontroller(char  file_path, char *print_require, char *delete_require, int* input_id)
{
	if (*input_id == USER)
	{
		if (*print_require == ENABLE)
		{
			//edit_status = ENABLE;
		}
		else if (*delete_require == ENABLE)
		{
			//delete_status = ENABLE;
		}
		else if (charge_status == DISABLE && *print_require == ENABLE)
		{

			//prin_status = ENABLE;

		}

	}

}