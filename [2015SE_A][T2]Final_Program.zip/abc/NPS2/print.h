#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"

void printfile(char *print_require)
{
	
		FILE *pFile2 = NULL;

		char name[20];
	
		int i = 0;
		int j = 0;
		sprintf(name, "%d%d%d%d%d%d.txt", clock_a(YEAR), clock_a(MON), clock_a(DAY), clock_a(HOUR), clock_a(MIN), clock_a(SEC));
		pFile2 = fopen(name, "w");

		
		for (i = 0; i < 1000; i++) {

			fputs(casting[0][i], pFile2);
			for (j = 0; j < 31; j++) {
				if (casting[0][i][j] == '\n')
				{
					break;
					// 30자보다 길이가 짧을때

				}
				else if (j == 30) {
					//casting[0][i][30] = '\n';
					fputc('\r\n', pFile2);// 30자보다 길때

				}
			}
		}

		for (i = 0; i < p_index; i++) {
			if (i < 4) {
				queue[i][0] = queue[i + 1][0];
				queue[i][1] = queue[i + 1][1];
			}
			else if (i == 4) {
				queue[i][0] ='\0';
				queue[i][1] = '\0';
			}
		}
		
		fclose(pFile2);
		print_status = DISABLE;
		*print_require = DISABLE;
		remain_status = ENABLE;
		control_status = ENABLE;
		p_index--;
		if (p_index != 0) {
			*print_require = ENABLE;
			print_status = ENABLE;
			clock_a(8);
		}
}
