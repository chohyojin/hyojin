#pragma once

#include "display.h"
#include "define.h"
#include "print.h"


/*
#define ADD_USER 0
#define CHECK_USER 1
#define DELETE_USER 2
#define CHARGE 3
#define PRINT 4
#define DELETE 5
*/

void controller(int input_id, char *print_require, char* file_path, int remainingData[2]) {
	
		//c_time = clock(7);
	display(c_time, input_id, &print_require, file_path, remainingData);
	
	if (*print_require == ENABLE && control_status ==ENABLE) {
		clock_a(8);
		s_time = clock_a(7);
		control_status = DISABLE;
	}
	
	if (*print_require==ENABLE && clock_a(7) >= p_time && charge_status == DISABLE) {
		printfile(print_require);
	}
	
}
