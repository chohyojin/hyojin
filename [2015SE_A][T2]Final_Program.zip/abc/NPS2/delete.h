#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"

void deletes(char *delete_require)
{
	if (*delete_require == ENABLE)
	{
		int i = 0;
		int j = 0;

		int d_time = 0;

		d_time = clock_a(7)-s_time;
		for (i = d_time * 10; i < 1000; i++){
			for (j = 0; j < 31; j++) {
				casting[0][i][j] = '\0';
			}
		}
		/*
		for (i = 0; i < 4;i++){
			for (j = 0; j < 1000; j++){
				for (k = 0; k < 31; k++){
					casting[i][j][k] = casting[i + 1][j][k];
				}
			}
		}
		for (i = 0; i < 1000; i++){
			for (j = 0; j < 31; j++){
				casting[4][i][j] = '\0';
			}
		}
		*/
		
		p_time = clock_a(7);
		*delete_require = DISABLE;
		
	}
}
