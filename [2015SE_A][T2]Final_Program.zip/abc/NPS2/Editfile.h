#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"



void Editfile(char* file_path, int input_id, char *print_require)
{
	if (*print_require == ENABLE&& file_path != NULL)
	{

		FILE *pFile = NULL;
		char strTemp[255];



		int i = 0;
		int j = 0;
		int k = 0;

		int l_count = 0;

		if (p_index > 4) {
			printf("�̹� ��⿭�� 5���� ������ �ֽ��ϴ�.");
			Sleep(2000);
			return;
		}

		pFile = fopen(file_path, "r");

		if (pFile != NULL)
		{



			while (!feof(pFile))
			{

				for (k = 0; k < sizeof(strTemp); k++)
				{
					strTemp[k] = '\0';
				}

				fgets(strTemp, sizeof(strTemp), pFile);

				strncpy(casting[p_index][j], strTemp, 30);

				l_count++;
				
				//casting[index][j][sizeof(casting[index][j]) - 1] = '\n';
				/*

				for (i = 0; i < 31; i++) {
					if (casting[index][j][i] == '\n')
					{
						// 30�ں��� ���̰� ª����
						break;

					}
					else if (i == 30 ) {
						casting[index][j][30] = '\n';      // 30�ں��� �涧

					}
				}
				*/
				
				j++;


			}
			queue[p_index][0] = input_id;
			if (l_count % 10 == 0) queue[p_index][1] = l_count / 10;
			else queue[p_index][1] = l_count / 10 + 1;
			p_index++;
				fclose(pFile);

				file_path[0] = NULL;
		}
		else 
		{
			printf("���� �����Դϴ�.");
			*print_require = DISABLE;
			print_status = DISABLE;
			Sleep(1000);
		}





	}
}
