#pragma once
#include "digital_clock.h"
#include "display.h"
#include "getCh.h"

void chargerI(int remainingData[2]) {
	int current_time = clock_a(7);
	int end_time = 0;
	printf("��ũ�ܷ� %d",remainingData[0]);
	int remaining_ink = (3099 - remainingData[0]) / 100;
	end_time = remaining_ink + current_time;
	int printtime = end_time - current_time;
	while (1) {

		remainingData[0] += 100;

		if (end_time+1 <= clock_a(7))
		{
			
			charge_status = DISABLE;
			
			if (remainingData[0] >= 3000) {
				remainingData[0] = 3000;
			}
			return;
		}
		
		/*
		remainingData[0] += 100;
		if (remainingData[0] >= 3000) {
			remainingData[0] = 3000;
		}*/
		system("clear");
		//gotoxy(0, 10);
		printf("��ü %d�� �� %d�� ���ҽ��ϴ�. ���� ��ũ��%d \n", printtime, (end_time - clock_a(7)),remainingData[0]-100);
		if (kbhit()) {
			
			if ((int)getch() == 120) {
				printf("������ �����մϴ�.\n");
				charge_status = DISABLE;
				return;
			}
		}
		Sleep(1000);
	}
}

void chargerP(int remainingData[2]) {
	int current_time = clock_a(7);
	int end_time = 0;
	int remaining_paper = (100 - remainingData[1]) / 10;
	end_time = remaining_paper + current_time;
	int printtime = end_time - current_time;
	while (1) {
		if (end_time+1 <= clock_a(7))
		{
			charge_status = DISABLE;
			if (remainingData[1] >= 100) {
				remainingData[1] = 100;
			}
			return;
		}
		remainingData[1] += 10;
		
		gotoxy(0, 10);
		printf("��ü %d�� �� %d�� ���ҽ��ϴ�. ���� ���̷� %d \n", printtime, (end_time - clock_a(7)), remainingData[1]-10);

		//fpurge(stdin);
		if (kbhit()) {
			
			
			if ((int)getch() == 120) {
				printf("������ �����մϴ�.\n");
				charge_status = DISABLE;

				return;
			}
		}
		Sleep(1000);
	}
}
