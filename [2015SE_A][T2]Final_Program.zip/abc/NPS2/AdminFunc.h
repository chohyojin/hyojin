#pragma once
#include "define.h"


void display_user_list() {
	int i = 0;

	printf("���� �㰡�� ����� ID: ");
	for (i = 1; i < USER_NUM; i++) {
		if (userList[i] == USER) {
			printf(" %d \n", i);
		}
	}
	Sleep(2000);
}

void initList(char userList[USER_NUM]) {
	int i=0;
	for (i = 0; i < 100; i++) {
		userList[i] = NOUSER;
	}
}

void initRemainingData(int remainingData[2]) {
	remainingData[0] = 3000;
	remainingData[1] = 100;
}

void addUser(int userID, char userList[USER_NUM]) {
	userList[userID] = USER;
}

void deleteUser(int userID, char userList[USER_NUM]) {
	if (userList[userID] == ADMIN) {
		printf("������ ���̵�� ���� �� �����ϴ�.\n");
		Sleep(1500);
		return;
	}
	userList[userID] = NOUSER;
}

void checkUser(int* check_status) {
	*check_status = ENABLE;
	display_user_list();
}

