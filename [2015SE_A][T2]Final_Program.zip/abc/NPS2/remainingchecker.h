#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"


void remainingchecker(char *print_require)
{
	char strTemp[255];
	int numLines = 0;
	
	int w_count = 0;
	int l_count = 0;

	int i = 0;
	int j = 0;
	int k = 0;

	for (i = 999; i >= 0; i--) {
		if (casting[0][i][0] != '\0') {
			i = i + 1;
			l_count = i;
			break;
		}
	}

	for (i; i >= 0; i--) {
		for (j = 0; j < 31; j++) {
			if (casting[0][i][j] != '\0'&&casting[0][i][j] != ' '&&casting[0][i][j] != '\n'&&casting[0][i][j] != '\t') {
				w_count++;
			}
		}
	}
	ink_consume = w_count;
	if(l_count%10==0) paper_consume = l_count / 10;
	else paper_consume = l_count / 10 + 1;

	


			if (remainingData[0] > ink_consume && remainingData[1] > paper_consume)
			{
				if (remain_status==ENABLE)
				{
					remainingData[0] -= ink_consume;
					remainingData[1] -= paper_consume;
					remain_status = DISABLE;

					//q pop

					for (i = 0; i < 4; i++) {
						for (j = 0; j < 1000; j++) {
							for (k = 0; k < 31; k++) {
								casting[i][j][k] = casting[i + 1][j][k];
							}
						}
					}
					for (i = 0; i < 1000; i++) {
						for (j = 0; j < 31; j++) {
							casting[4][i][j] = '\0';
						}
					}
				}

			}
			else
			{
				*print_require = LACK;
				print_status = DISABLE;
				printf("��ũ �Ǵ� ������ �ܷ��� �����մϴ�\n");
				Sleep(2000);
				
			}
			
}
