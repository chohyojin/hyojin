#pragma once

#include "display.h"
#include "define.h"
#include "print.h"


/*
#define ADD_USER 0
#define CHECK_USER 1
#define DELETE_USER 2
#define CHARGE 3
#define PRINT 4
#define DELETE 5
*/

void controller(int c_time, int input_id, char print_require, char* file_path, int remainingData[2]) {
	if(charge_status==DISABLE)
		c_time = clock_a(7);
	display(c_time, input_id, print_require, file_path, remainingData);
	
	if (print_require == ENABLE && control_status ==ENABLE) {
		clock_a(8);
		control_status = DISABLE;
	}
	if (c_time == p_time) {
		printfile(print_require);
	}
	
}