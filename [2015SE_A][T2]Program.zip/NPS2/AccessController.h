#pragma once
#include <stdio.h>
#include <string.h>
#include <Windows.h>

#include"define.h"
#include "display.h"

void accessController(int* input_id, char* print_require, char* delete_require, char* ink_charge, char* paper_charge, char* add_user, char* delete_user, char* user_check, char file_path[FILE_LENTH])
{
	char inputString[100];	
	
	int k = 1;
	int i = 0;
	int flag = 1;

	if (kbhit()) {
		
		system("cls");
		gotoxy(0, 10);
		
		while (1)
		{
			printf("ID�Է�: ");
			getchar();
			scanf("%d", input_id);
			if (*input_id<0) {
				return;
			}
			else if (*input_id > DEFAULT && *input_id < USER_NUM && (userList[*input_id] == USER))
			{
				while (1 == flag) {
					printf("USER ���ɾ� �Է�: ");
					scanf("%s", inputString);
					if (strcmp(inputString, "print") == 0) {
						flag = 0;
						printf("���� �̸� �Է�: ");
						scanf("%s", file_path);
						control_status = ENABLE;
						*print_require = ENABLE;
						return;
					}
					if (strcmp(inputString, "delete") == 0) {
						flag = 0;
						*delete_require = ENABLE;
						return;
					}
				}

			}
			else if (*input_id == DEFAULT && userList[*input_id] == ADMIN)
			{
				printf("ADMIN ���ɾ� �Է�: ");
				scanf("%s", inputString);

				if (strcmp(inputString, "ink_charge") == 0) {
					*ink_charge = ENABLE;
					return;
				}
				else if (strcmp(inputString, "paper_charge") == 0) {
					*paper_charge = ENABLE;
					return;
				}

				else if (strcmp(inputString, "add_user") == 0) {
					*add_user = ENABLE;
					printf("�߰��� ���� ���̵� :");
					scanf("%d", input_id);
					return;
				}
				else if (strcmp(inputString, "delete_user") == 0) {
					*delete_user = ENABLE;
					printf("������ ���� ���̵� :");
					scanf("%d", input_id);
					return;
				}
				else if (strcmp(inputString, "User check") == 0) {
					*user_check = ENABLE;
					return;
				}
			}
			else if (strcmp(inputString, "exit") == 0) {
				exit(1);
			}
			else
			{
				printf("�ٽ� �Է��ϼ���.\n");
			}
		}
	}
}