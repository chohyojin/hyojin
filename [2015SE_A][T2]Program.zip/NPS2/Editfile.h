#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"



void Editfile(char* file_path, int input_id, char print_require)
{
	if (print_require == ENABLE)
	{

		FILE *pFile = NULL;
		char strTemp[255];
		


		int i = 0;
		int j = 0;
		int k = 0;

		pFile = fopen(file_path, "r");

		if (pFile != NULL)
		{



			while (!feof(pFile))
			{

				for (k = 0; k < sizeof(strTemp); k++)
				{
					strTemp[k] = '\0';
				}

				fgets(strTemp, sizeof(strTemp), pFile);

				strncpy(casting[p_index][j], strTemp, 30);


				casting[p_index][j][sizeof(casting[p_index][j]) - 1] = '\0';


				for (i = 0; i < 31; i++) {
					if (casting[p_index][j][i] == '\n')
					{
						// 30�ں��� ���̰� ª����

					}
					else if (i == 30) {
						casting[p_index][j][30] = '\n';      // 30�ں��� �涧

					}
				}

				j++;


			}

			fclose(pFile);


		}
		else
		{
			//���� ó��
		}





	}
}