#pragma once
#include "digital_clock.h"
#include "display.h"

void chargerI(int remainingData[2]) {
	int current_time = clock_a(7);
	int end_time = 0;
	printf("��ũ�ܷ� %d",remainingData[0]);
	int remaining_ink = (30000 - remainingData[0]) / 100;
	end_time = remaining_ink + current_time;
	int printtime = end_time - current_time;
	while (1) {
		if (end_time <= clock_a(7))
		{
			charge_status = DISABLE;
			return;
		}
		remainingData[0] += 100;
		if (remainingData[0] >= 30000) {
			remainingData[0] = 30000;
		}
		gotoxy(0, 10);
		printf("��ü %d�� �� %d�� ���ҽ��ϴ�.", printtime, (end_time - clock_a(7)));
		if (kbhit()) {
			if ((int)getchar() == 27) {
				printf("������ �����մϴ�.");
				charge_status = DISABLE;
				return;
			}
		}
		Sleep(1000);
	}
}

void chargerP(int remainingData[2]) {
	int current_time = clock_a(7);
	int end_time = 0;
	int remaining_paper = (100 - remainingData[1]) / 10;
	end_time = remaining_paper + current_time;
	int printtime = end_time - current_time;
	while (1) {
		if (end_time <= clock_a(7))
		{
			charge_status = DISABLE;
			return;
		}
		remainingData[1] += 10;
		if (remainingData[1] >= 100) {
			remainingData[1] = 100;
		}
		gotoxy(0, 10);
		printf("��ü %d�� �� %d�� ���ҽ��ϴ�.", printtime, (end_time - clock_a(7)));
		if (kbhit()) {
			if ((int)getchar() == 27) {
				printf("������ �����մϴ�.");
				charge_status = DISABLE;
				return;
			}
		}
		Sleep(1000);
	}
}