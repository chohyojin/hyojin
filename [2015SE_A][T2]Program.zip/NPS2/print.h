﻿#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"

void printfile(char print_require)
{
	
		FILE *pFile2 = NULL;

		char name[20];

		int i = 0;
		int j = 0;
		int k = 0;

		sprintf(name, "%d%d%d%d%d%d.txt", clock_a(YEAR), clock_a(MON), clock_a(DAY), clock_a(HOUR), clock_a(MIN), clock_a(SEC));
		pFile2 = fopen(name, "w");

		for (i = 0; i < 1000; i++) {
			fputs(casting[0][i], pFile2);
		}
		fclose(pFile2);
		print_status = DISABLE;
		print_require = DISABLE;
		//ť pop
		
		for (i = 0; i < 4; i++) {
			for (j = 0; j < 1000; j++) {
				for (k = 0; k < 31; k++) {
					casting[i][j][k] = casting[i + 1][j][k];
				}
			}
		}
		for (i = 0; i < 1000; i++) {
			for (j = 0; j < 31; j++) {
				casting[4][i][j] = '\0';
			}
		}
	
}
