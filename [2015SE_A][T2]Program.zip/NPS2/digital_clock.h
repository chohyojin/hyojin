#pragma once

#include <time.h>
#include "Editfile.h"
#include "define.h"

#define YEAR 1
#define MON 2
#define DAY 3
#define HOUR 4
#define MIN 5
#define SEC 6
#define TOTAL_SEC 7
#define C_TIME 8


int clock_a(int select) {
	time_t timer;
	struct tm *t;
	int i = 0;

	time(&timer);
	t = localtime(&timer);
	timer= time(NULL); // ���� �ð��� �� ������ ���
	 // �� ������ �ð��� �и��Ͽ� ����ü�� �ֱ�


	if (select == YEAR)
		return t->tm_year + 1900;
	else if (select == MON)
		return t->tm_mon + 1;
	else if (select == DAY)
		return t->tm_mday;
	else if (select == HOUR)
		return t->tm_hour;
	else if (select == MIN)
		return t->tm_min;
	else if (select == SEC)
		return t->tm_sec;
	else if (select == TOTAL_SEC)
		return timer;
	else if (select == C_TIME) {

		for (i = 1000; i >= 0; i--) {
			if (casting[0][i][0] != '\0') {
				p_time = timer + ((i + 1) / 10 + 1);

				return p_time;
			}
		}
		return -1;
	}
	else
		return -1;
}
