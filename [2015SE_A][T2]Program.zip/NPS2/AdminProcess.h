#pragma once
#include "define.h"
#include "AdminFunc.h"
#include "charge.h"


void adminProcess(int userID, char* ink_charge, char* paper_charge, char* add_user, char* delete_user, char* user_check) {

	if (*add_user == ENABLE) {
		addUser(userID, userList);
		*add_user = DISABLE;
	}
	if (*delete_user == ENABLE) {
		deleteUser(userID, userList);
		*delete_user = DISABLE;
	}
	if (*user_check == ENABLE) {
		checkUser(check_status);
	}
	if ((*ink_charge == ENABLE || *paper_charge == ENABLE) && print_status == DISABLE && (remainingData[0] < 30000 || remainingData[1] < 100)) {
		printf("������");
		if(*ink_charge)chargerI(remainingData);
		else if (*paper_charge)chargerP(remainingData);
		*ink_charge = DISABLE;
		*paper_charge = DISABLE;
		charge_status = ENABLE;
	}
}
	