#pragma once
#include "define.h"

void initList(char userList[USER_NUM]) {
	int i;
	for (i = 0; i < 100; i++) {
		userList[i] = NOUSER;
	}
}

void initRemainingData(int remainingData[2]) {
	remainingData[0] = 30000;
	remainingData[1] = 100;
}

void addUser(int userID, char userList[USER_NUM]) {
	userList[userID] = USER;
}

void deleteUser(int userID, char userList[USER_NUM]) {
	userList[userID] = NOUSER;
}

void checkUser(int check_status) {
	check_status = ENABLE;
}

