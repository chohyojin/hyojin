#pragma once
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <Windows.h>
#include "digital_clock.h"
#include "define.h"


void remainingchecker(char print_require)
{
	char strTemp[255];
	int numLines = 0;
	
	int w_count = 0;
	int l_count = 0;

	int i = 0;
	int j = 0;

	for (i = 1000; i >= 0; i--) {
		if (casting[0][i][0] != '\0') {
			i = i + 1;
			l_count = i;
			break;
		}
	}

	for (i; i >= 0; i--) {
		for (j = 0; j < 31; j++) {
			if (casting[0][i][j] != '\0') {
				w_count++;
			}
		}
	}
	ink_consume = w_count;
	paper_consume = l_count / 10 + 1;

	


			if (remainingData[0] > ink_consume && remainingData[1] > paper_consume)
			{
				remainingData[0] -= ink_consume;
				remainingData[1] -= paper_consume;
			
			}
			else
			{
				print_require = LACK;
			}
			
}
