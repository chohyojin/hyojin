package my_member;

public class MemberVo {
	
	private String id;
	private String pass;
	private String name;
	private String ph1;
	private String ph2;
	private String ph3;
	private String gender;
	private int birth1;
	private int birth2;
	private int birth3;
	public MemberVo()
	{
		
	}
    public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPh1() {
		return ph1;
	}
	public void setPh1(String ph1) {
		this.ph1 = ph1;
	}
	public String getPh2() {
		return ph2;
	}
	public void setPh2(String ph2) {
		this.ph2 = ph2;
	}
	public String getPh3() {
		return ph3;
	}
	public void setPh3(String ph3) {
		this.ph3 = ph3;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getBirth1() {
		return birth1;
	}
	public void setBirth1(int birth1) {
		this.birth1 = birth1;
	}
	public int getBirth2() {
		return birth2;
	}
	public void setBirth2(int birth2) {
		this.birth2 = birth2;
	}
	public int getBirth3() {
		return birth3;
	}
	public void setBirth3(int birth3) {
		this.birth3 = birth3;
	}
	
	

}
