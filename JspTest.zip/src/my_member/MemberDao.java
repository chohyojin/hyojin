package my_member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import my_util.ConnUtil;

public class MemberDao {
	
	public int loginCheck(String id, String pass){
		  int rst = 0;
		  Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		  try{
		   conn = ConnUtil.getConnection();
		   String sql = "select * from member where id=?";
		   ps = conn.prepareStatement(sql);
		   ps.setString(1, id);
		   rs = ps.executeQuery();
		   if(rs.next()){
		    String DBpass = rs.getString("pass");
		     if((DBpass.trim()).equals((pass.trim()))){
		      rst=2;  // 로그인성공
		     }else{
		      rst=1;   // 비밀번호 틀림
		     }
		    }  // 아이디 없음
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   ConnUtil.close(rs, ps, conn);
		  }
		  return rst;
		 }

	public int idCheck(String id){
		  int rst = 0;
		  Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		  try{
		   conn = ConnUtil.getConnection();
		   String sql = "select * from member where id=?";
		   ps = conn.prepareStatement(sql);
		   ps.setString(1, id);
		   rs = ps.executeQuery();
		   if(rs.next()){
		    rst = 1;
		   }
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   ConnUtil.close(rs, ps, conn);
		  }
		  return rst;
		 }

		


 public int insertMember(MemberVo vo){
  int rst = 0;
  Connection conn = null;
  PreparedStatement ps = null;
  try{
	 
   conn = ConnUtil.getConnection();
   String sql = "insert into member values(null,?,?,?,?,?,?,?,?,?,?,sysdate())";
   ps = conn.prepareStatement(sql);
   ps.setString(1, vo.getId());
   ps.setString(2, vo.getPass());
   ps.setString(3, vo.getName()); 
   ps.setString(4, vo.getPh1());
   ps.setString(5, vo.getPh2());
   ps.setString(6, vo.getPh3());
   ps.setString(7, vo.getGender());
   ps.setInt(8, vo.getBirth1());
   ps.setInt(9, vo.getBirth2());
   ps.setInt(10, vo.getBirth3());

   rst = ps.executeUpdate();
    
  }catch(Exception e){
   e.printStackTrace();
  }finally{
	  ConnUtil.close(ps,conn);
 
  }
  return rst;
 }
 
 public MemberVo selectMember(String id){
	 MemberVo vo = new MemberVo();
	  Connection conn = null;
	  PreparedStatement ps = null;
	  ResultSet rs = null;
	  try{
	   conn = ConnUtil.getConnection();
	   String sql = "select * from member where id = ?";
	   ps = conn.prepareStatement(sql);
	   ps.setString(1, id);
	   rs = ps.executeQuery();
	   if(rs.next()){
	    vo.setId(rs.getString("id"));
	   
	  
	   
	   }
	  }catch(Exception e){
	   e.printStackTrace();
	  }finally{
	   ConnUtil.close(rs, ps, conn);
	  }
	  return vo;
	 }
}




