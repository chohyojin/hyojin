package my_point;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import my_member.MemberVo;
import my_util.ConnUtil;

public class PointDao {
	private int k1=0;
	 public void insertPoint(MemberVo vo){
		 int j=0;
		 Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "insert into point values(?,0)";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, vo.getId());
			 ps.executeUpdate();
			 
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void selectPoint(String id){
		 int j=0;
		 Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from point where id = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, id);
			 rs = ps.executeQuery();
			 while(rs.next()){
				if(j==0){
					k1=rs.getInt("cost");
				}
				j++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	public void increPoint(String id,int k2){
		  Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
        try{
			 
		   conn = ConnUtil.getConnection();
		   String sql = "update point set cost=? where id=?";
		   ps = conn.prepareStatement(sql);
		   ps.setInt(1, k1+k2);
		   ps.setString(2, id);
		   ps.executeUpdate();
		    
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  ConnUtil.close(ps,conn); 
		  }
		 }
	
	
	public void decrePoint(String id,int k2){
		  Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
      try{
			 
		   conn = ConnUtil.getConnection();
		   String sql = "update point set cost=? where id=?";
		   ps = conn.prepareStatement(sql);
		   ps.setInt(1, k1-k2);
		   ps.setString(2, id);
		   ps.executeUpdate();
		    
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  ConnUtil.close(ps,conn); 
		  }
		 }
}
