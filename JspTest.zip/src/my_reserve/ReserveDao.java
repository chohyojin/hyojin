package my_reserve;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import my_theater.TheaterVo;
import my_util.ConnUtil;

public class ReserveDao {
	private String s1,s2,s3=null;
	private int k=0;
	public void insertReservation(String id){
		  Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
        try{
			 
		   conn = ConnUtil.getConnection();
		   String sql = "insert into reserve values(null,null,null,null,?)";
		   ps = conn.prepareStatement(sql);
		   ps.setString(1, id);
		   ps.executeUpdate();
		    
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  ConnUtil.close(ps,conn); 
		  }
		 }
	
	 public int reserveM(TheaterVo vo1,ReserveVo vo2){
		 int j=0;
		 Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from theater where movietitles = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, vo1.getMovietitles());
			 rs = ps.executeQuery();
			 while(rs.next()){
				if(vo2.getSelecting()==j){
					s1=rs.getString("movietitles");
					s2=rs.getString("moviedimension");
					s3=rs.getString("movietime");
					k=rs.getInt("remainseat")-1;
				}
				
				j++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
			 if(s2=="2D"){
					return 1000;
				}
			 else{
				 return 1400;
			 }
		 }
	 }
	 public void reserveO(String id,ReserveVo vo){
		 int j=0;
		 Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "insert into reserve(title,sort,time,s_num,id) values(?,?,?,?,?)";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, s1);
			 ps.setString(2, s2);
			 ps.setString(3, s3);
			 ps.setString(4, vo.getS_num());
			 ps.setString(5, id);
			 ps.executeUpdate();
	 }catch(Exception e){
		 e.printStackTrace();
	 }
	 finally{
		 ConnUtil.close(ps,conn);
	 }
	 }
	 public void reserveV(){
		 Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "update theater set remainseat = ? where movietime = ? and movietitles = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setInt(1, k);
			 ps.setString(2, s3);
			 ps.setString(3, s1);
			 ps.executeUpdate();
	 }catch(Exception e){
		 e.printStackTrace();
	 }
	 finally{
		 ConnUtil.close(ps,conn);
	 }
	 }
}
