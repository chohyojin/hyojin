package my_reserve;

public class ReserveVo {
   int selecting;
   String s_num;

public String getS_num() {
	return s_num;
}

public void setS_num(String s_num) {
	this.s_num = s_num;
}

public int getSelecting() {
	return selecting;
}

public void setSelecting(int selecting) {
	this.selecting = selecting;
}
}
