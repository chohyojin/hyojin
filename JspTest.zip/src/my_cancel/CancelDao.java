package my_cancel;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;

import my_util.ConnUtil;

public class CancelDao {
	 Connection conn = null;
	  PreparedStatement ps = null;
	  java.sql.Statement stmt = null;
	  String sql;
	  public int i=0;
	  private int k=0;
	  public String[] htitle = new String[100];
	 String s1,s2,s3,s4=null;
	  java.sql.ResultSet rs =null;
	
	 public void showTheater(String id){
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from reserve where id = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, id);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 htitle[i]=" �󿵰����� : "+rs.getString("sort")+" ��ȭ�ð�: "+rs.getString("time")+"  �¼� ��ȣ: "+rs.getString("s_num");
				 i++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public int cancelM(String id,CancelVo vo){
		 int j=0;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from reserve where id = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, id);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 if(vo.getCanceling()==j){
						s1=rs.getString("title");
						s2=rs.getString("s_num");
						s3=rs.getString("time");
						s4=rs.getString("sort");
					}
				 j++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
			 if(s2=="2D"){
					return 1000;
				}
			 else{
				 return 1400;
			 }
		 }
	 }
	 public void cancelO(){
		
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "delete from reserve where title =? and s_num =? and time=?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, s1);
			 ps.setString(2, s2);
			 ps.setString(3, s3);
			 ps.executeUpdate();
			
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelV(CancelVo vo){
		 int j=0;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from theater where movietitles = ? and movietime = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, s1);
			 ps.setString(2, s3);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 if(j==0){
						k=rs.getInt("remainseat")+1;
					}
				 j++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelI(){
			 Connection conn = null;
			  PreparedStatement ps = null;
			  ResultSet rs = null;
			 try{
				 conn = ConnUtil.getConnection();		
				 String sql = "update theater set remainseat = ? where movietime = ? and movietitles = ?";
				 ps = conn.prepareStatement(sql);
				 ps.setInt(1, k);
				 ps.setString(2, s3);
				 ps.setString(3, s1);
				 ps.executeUpdate();
			 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }


	 }