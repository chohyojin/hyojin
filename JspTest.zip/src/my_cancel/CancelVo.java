package my_cancel;

public class CancelVo {
  int canceling;

public int getCanceling() {
	return canceling;
}

public void setCanceling(int canceling) {
	this.canceling = canceling;
}
}
