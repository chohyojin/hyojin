package my_theater;

public class TheaterVo {
	
	private int remainseat;
	private String moviedimension;
	private String movietime;
	public String movietitles;
	private int theaternum;
	private int canceling;
	public int getCanceling() {
		return canceling;
	}
	public void setCanceling(int canceling) {
		this.canceling = canceling;
	}
	public int getRemainseat() {
		return remainseat;
	}
	public void setRemainseat(int remainseat) {
		this.remainseat = remainseat;
	}
	public String getMoviedimension() {
		return moviedimension;
	}
	public void setMoviedimension(String moviedimension) {
		this.moviedimension = moviedimension;
	}
	public String getMovietime() {
		return movietime;
	}
	public void setMovietime(String movietime) {
		this.movietime = movietime;
	}
	public String getMovietitles() {
		return movietitles;
	}
	public void setMovietitles(String movietitles) {
		this.movietitles = movietitles;
	}
	public int getTheaternum() {
		return theaternum;
	}
	public void setTheaternum(int theaternum) {
		this.theaternum = theaternum;
	}
	
	

}
