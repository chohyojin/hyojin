package my_theater;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;

import my_util.ConnUtil;

public class TheaterDao {
	 Connection conn = null;
	  PreparedStatement ps = null;
	  java.sql.Statement stmt = null;
	  String sql;
	  public int i=0;
	  public String[] htitle = new String[100];
	 
	  java.sql.ResultSet rs =null;
	 public int insertTheater(TheaterVo vo1){
		  int rst = 0;
		  try{
			 
		   conn = ConnUtil.getConnection();
		   sql = "insert into theater values(?,?,?,?,?)";
		   ps = conn.prepareStatement(sql);
		   ps.setInt(1, vo1.getRemainseat());
		   ps.setString(2, vo1.getMoviedimension());
		   ps.setString(3, vo1.getMovietime()); 
		   ps.setString(4, vo1.getMovietitles());
		   ps.setInt(5, vo1.getTheaternum());
		   rst = ps.executeUpdate();
		    
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  ConnUtil.close(ps,conn);
		 
		  }
		  return rst;
		 }
	 public TheaterVo selectTheater(String movietitles){
		  TheaterVo vo = new TheaterVo();
		  Connection conn = null;
		  PreparedStatement ps = null;
		  ResultSet rs = null;
		  try{
		   conn = ConnUtil.getConnection();
		   String sql = "select * from theater where movietitles = ?";
		   ps = conn.prepareStatement(sql);
		   ps.setString(1, movietitles);
		   rs = ps.executeQuery();
		   if(rs.next()){
		    vo.setRemainseat(rs.getInt("remainseat"));
		    vo.setMoviedimension(rs.getString("moviedimension"));
		    vo.setMovietime(rs.getString("movietime"));
		    vo.setMovietitles(rs.getString("movietitles"));
		    vo.setTheaternum(rs.getInt("theaternum"));
		  
		   
		   }
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   ConnUtil.close(rs, ps, conn);
		  }
		  return vo;
		 }
	 public void showTheater(TheaterVo vo1){
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from theater where movietitles = ?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, vo1.getMovietitles());
			 rs = ps.executeQuery();
			 while(rs.next()){
				if(rs.getInt("remainseat")>0) htitle[i]="�����¼� : "+rs.getString("remainseat")+" �󿵰����� : "+rs.getString("moviedimension")+" ��ȭ�ð�: "+rs.getString("movietime")+"  ��ȭ�� ��ȣ: "+rs.getString("theaternum");
				else htitle[i] = "���źҰ� (�¼� ��)";
				i++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }


	 }