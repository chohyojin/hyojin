package my_theater;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;

import my_util.ConnUtil;

public class MovieCDao {
	 Connection conn = null;
	  PreparedStatement ps = null;
	  java.sql.Statement stmt = null;
	  String sql;
	  public int i=0;
	  private int k=0;
	  public String[] htitle = new String[100];
	 String s1=null;
	  java.sql.ResultSet rs =null;
	
	 public void showMovie(){
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from movie2";
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 htitle[i]=" Ÿ��Ʋ : "+rs.getString("title")+" �󿵽ð�: "+rs.getInt("minute")+"  ���ɰ�: "+rs.getString("age")+" �帣:"+rs.getString("genre");
				 i++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelM(TheaterVo vo){
		 int j=0;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from movie2";
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 if(vo.getCanceling()==j){
						s1=rs.getString("title");
					}
				 j++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelO(){
		
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "delete from movie2 where title =?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, s1);
			 ps.executeUpdate();
			
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelV(){
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "delete from theater where movietitles =?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, s1);
			 ps.executeUpdate();
			
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 


	 }