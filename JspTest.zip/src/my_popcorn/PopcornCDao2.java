package my_popcorn;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;

import my_util.ConnUtil;

public class PopcornCDao2 {
	 Connection conn = null;
	  PreparedStatement ps = null;
	  java.sql.Statement stmt = null;
	  String sql;
	  public int i=0;
	  private int k=0;
	  public String[] htitle = new String[100];
	 String s1,s2=null;
	  java.sql.ResultSet rs =null;
	
	 public void showPopcorn(){
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from popcorn";
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 htitle[i]=" ���� : "+rs.getString("name")+" ����: "+rs.getString("cost")+"  ������: "+rs.getString("size");
				 i++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelM(PopcornVo vo){
		 int j=0;
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from popcorn";
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 if(vo.getPopcorning()==j){
						s1=rs.getString("name");
						k=rs.getInt("cost");
						s2=rs.getString("size");
					}
				 j++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	 public void cancelO(){
		
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "delete from popcorn where name =? and cost =? and size=?";
			 ps = conn.prepareStatement(sql);
			 ps.setString(1, s1);
			 ps.setInt(2, k);
			 ps.setString(3, s2);
			 ps.executeUpdate();
			
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }
	

	 }