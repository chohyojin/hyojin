package my_popcorn;

public class PopcornVo {
	private String name;
	private int cost;
	private String size;
	private String time;
	private int popcorning;
	public int getPopcorning() {
		return popcorning;
	}
	public void setPopcorning(int popcorning) {
		this.popcorning = popcorning;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

}
