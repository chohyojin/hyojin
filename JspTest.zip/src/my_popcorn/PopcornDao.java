package my_popcorn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import my_theater.TheaterVo;
import my_util.ConnUtil;
public class PopcornDao {
	
	 private String s1,s2=null;
	 private int k=0;
	 Connection conn = null;
	  PreparedStatement ps = null;
	  java.sql.Statement stmt = null;
	  String sql;
	  public int i=0;
	  public String[] htitle = new String[100];
	 
	  java.sql.ResultSet rs =null;
	public int insertPopcorn(PopcornVo vo){
			  int rst=0;
		      Connection conn = null;
			  PreparedStatement ps = null;
			  ResultSet rs = null;
	        try{
				 
			   conn = ConnUtil.getConnection();
			   String sql = "insert into popcorn values(?,?,?)";
			   ps = conn.prepareStatement(sql);
			   ps.setString(1,vo.getName());
			   ps.setInt(2,vo.getCost());
			   ps.setString(3,vo.getSize());
			   rst=ps.executeUpdate();
			    
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
				  ConnUtil.close(ps,conn); 
			  }
	        return rst;
			 }
	    public void showPopcorn(){
		 try{
			 conn = ConnUtil.getConnection();		
			 String sql = "select * from popcorn";
			 ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			 while(rs.next()){
				htitle[i]="�������� : "+rs.getString("name")+" ����: "+rs.getInt("cost")+" ������: "+rs.getString("size");
				i++;
			 }
		  }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	    }
		 public int reserveP(PopcornVo vo2){
			 int j=0;
			 Connection conn = null;
			  PreparedStatement ps = null;
			  ResultSet rs = null;
			 try{
				 conn = ConnUtil.getConnection();		
				 String sql = "select * from popcorn";
				 ps = conn.prepareStatement(sql);
				 rs = ps.executeQuery();
				 while(rs.next()){
					if(vo2.getPopcorning()==j){
						s1=rs.getString("name");
						s2=rs.getString("size");
						k=rs.getInt("cost");
					}
					j++;
				 }
			 }catch(Exception e){
				 e.printStackTrace();
			 }
			 finally{
				 ConnUtil.close(ps,conn);
			 
			return k/10;}
		 }
		 public void reserveO(String id,PopcornVo vo){
			 int j=0;
			 Connection conn = null;
			  PreparedStatement ps = null;
			  ResultSet rs = null;
			 try{
				 conn = ConnUtil.getConnection();		
				 String sql = "insert into reservep values(?,?,?,?,?)";
				 ps = conn.prepareStatement(sql);
				 ps.setString(1, s1);
				 ps.setInt(2, k);
				 ps.setString(3, s2);
				 ps.setString(4, vo.getTime());
				 ps.setString(5, id);
				 ps.executeUpdate();
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
		 }
		 


}
