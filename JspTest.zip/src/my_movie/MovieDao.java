package my_movie;

import java.sql.Connection;

import java.sql.PreparedStatement;


import my_util.ConnUtil;

public class MovieDao {
	 Connection conn = null;
	  PreparedStatement ps = null;
	  java.sql.Statement stmt = null;
	  String sql;
	  public String[] mtitle = new String[100];
	  public int i=0;
	  java.sql.ResultSet rs =null;
	 public int insertMovie(MovieVo vo1){
		  int rst = 0;
		  try{
			 
		   conn = ConnUtil.getConnection();
		   sql = "insert into movie2(title,minute,age,genre) values(?,?,?,?)";
		   ps = conn.prepareStatement(sql);
		   ps.setString(1, vo1.getMovietitle());
		   ps.setInt(2, vo1.getMinutes());
		   ps.setString(3, vo1.getAge()); 
		   ps.setString(4, vo1.getGenre());
	

		   rst = ps.executeUpdate();
		    
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  ConnUtil.close(ps,conn);
		 
		  }
		  return rst;
		 }
	 public void showMovie(){
		 try{
			 conn = ConnUtil.getConnection();
			 stmt = conn.createStatement();
			 sql = "select * from movie2";
			 rs = stmt.executeQuery(sql);
			 while(rs.next()){
				 mtitle[i]=rs.getString("title");
				 i++;
			 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			 ConnUtil.close(ps,conn);
		 }
	 }

}
